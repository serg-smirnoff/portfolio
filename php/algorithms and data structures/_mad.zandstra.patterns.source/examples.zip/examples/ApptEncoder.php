<?php

abstract class ApptEncoder {

   abstract function encode();
}

?>