<?php

abstract class Command {
   abstract function execute( CommandContext $context );
}

?>