<?php

class LaserCannonUnit extends Unit {
   function bombardStrength() {
      return 44;
   }
}

?>
