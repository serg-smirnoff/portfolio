<?php

class woo_base_AppException extends Exception { }

?>