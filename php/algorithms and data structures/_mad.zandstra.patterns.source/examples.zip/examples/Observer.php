<?php

interface Observer {
   function update( Observable $observable );
}

?>