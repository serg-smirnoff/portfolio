<?php

class woo_mapper_VenueCollection extends woo_mapper_Collection {

   function targetClass( ) {
   return 'woo_domain_Venue';
   }
}


?>