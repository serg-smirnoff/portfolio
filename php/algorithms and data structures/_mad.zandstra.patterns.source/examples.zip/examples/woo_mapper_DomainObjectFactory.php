<?php

abstract class woo_mapper_DomainObjectFactory {
   abstract function createObject( array $array );
}


?>