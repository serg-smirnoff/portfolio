<?php

interface Module {
   function execute();
}

?>