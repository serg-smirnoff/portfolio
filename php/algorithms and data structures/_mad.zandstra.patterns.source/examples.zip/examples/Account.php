<?php
class Account {
   public $balance;

   function __construct( $balance ) {
      $this->balance = $balance;
   }
}
?>