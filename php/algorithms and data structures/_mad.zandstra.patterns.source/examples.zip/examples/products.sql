CREATE TABLE products (
                          id INTEGER PRIMARY KEY AUTOINCREMENT,
                        type TEXT,
                   firstname TEXT,
                    mainname TEXT,
                       title TEXT,
                       price float,
                    numpages int,
                  playlength int,
                    discount int
                      )
