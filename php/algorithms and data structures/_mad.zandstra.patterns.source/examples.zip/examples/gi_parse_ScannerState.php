<?php


class gi_parse_ScannerState {
   public $line_no;
   public $char_no;
   public $token;
   public $token_type;
   public $r; 
}


?>