<?php

class Archer extends Unit {
   function bombardStrength() {
      return 4;
   }
}


?>