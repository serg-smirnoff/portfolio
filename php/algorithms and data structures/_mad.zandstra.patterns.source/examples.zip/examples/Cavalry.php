<?php

class Cavalry extends Unit {
   function bombardStrength() {
      return 2;
   }
}


?>
