<?php
 header('Content-Type: text/xml');
 echo '<?xml version="1.0" ?>';
 echo '<document>';
echo '<data>';
echo 'Here';
echo '</data>';

echo '<data>';
echo 'is';
echo '</data>';

echo '<data>';
echo 'some';
echo '</data>';

echo '<data>';
echo 'XML.';
echo '</data>';
echo '</document>';

?>