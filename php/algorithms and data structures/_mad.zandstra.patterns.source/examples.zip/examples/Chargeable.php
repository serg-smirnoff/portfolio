<?php
interface Chargeable {
   public function getPrice();
}
?>