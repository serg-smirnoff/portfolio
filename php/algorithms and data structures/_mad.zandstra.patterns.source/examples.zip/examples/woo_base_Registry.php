<?php

abstract class woo_base_Registry {
   abstract protected function get( $key );
   abstract protected function set( $key, $val );
}


?>